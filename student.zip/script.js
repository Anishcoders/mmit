// alert ('welcome to MMIT College');



const myButton = document.getElementById('myBtn');

        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          if(document.body.scrollTop > 100 || document.documentElement < 100) {
            myButton.style.display = "none";
          }
          
          else{
            myButton.style.display = "block";
          }
        }

        myButton.addEventListener('click', () => {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        })